# v5 전체 다시 실행 (프로젝트 폴더 어디에 풀어도 됨). 사용법: python -I code/run_all.py
# 순서: 노선 정리표 → 시간표 검사 → 노선 모형 → 건물 점수 5판 → ID 근거 → A·B·C → 완료표 → 지도
# (건물 대표점 만들기 v3_step3_buildings.py는 원본 건물 shp가 있어야 해서 기본 실행에서 뺌. 결과 out/v3/buildings_points.gpkg를 함께 제공)
import subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
STEPS = [['v3_step2_routes.py'], ['v5_tt_scan.py'], ['v5_route_model.py'],
         ['v5_scores.py', 'h_tt'], ['v5_scores.py', 'h_api'], ['v5_scores.py', 'h_best'], ['v5_scores.py', 'h_worst'], ['v5_scores.py', 'h_v4fix33'],
         ['v5_id_evidence.py'], ['v5_abc.py'], ['v5_completion.py'], ['v5_abc_map.py']]
for s in STEPS:
    t = time.time()
    r = subprocess.run([sys.executable, '-I', str(ROOT / 'code' / s[0]), *s[1:]], capture_output=True, text=True)
    print(f"[{'OK' if r.returncode == 0 else '실패'}] {' '.join(s)} ({time.time() - t:.0f}초)")
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-3000:]); sys.exit(1)
print('완료: 결과는 out/v5/')
