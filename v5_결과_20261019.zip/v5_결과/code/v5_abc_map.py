# A·B·C(+D 탐색 비교)가 고른 8개 동과 저접근 건물 지도 v5 — 윗줄: 전체, 아랫줄: 시가지 확대
#  주황 = 고른 동 안의 저접근(포착) / 파랑 = 고른 동 밖의 '확인된' 저접근(놓침) / 청록 빈 원 = 미확인(주 분석에서 제외, 판정 안 함)
from pathlib import Path
import pandas as pd, geopandas as gpd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
plt.rcParams['font.family'] = 'Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus'] = False
ROOT = Path(__file__).resolve().parents[1]; O = ROOT / 'out/v5'
CAP, MISS, UNK = '#eb6834', '#2a78d6', '#1baf7a'
INK, INK2, FILL = '#0b0b0b', '#52514e', '#e9e7e1'
adm = gpd.read_file(ROOT / 'data/ext/admdong.geojson').to_crs(5186)
area = adm[adm.adm_nm.str.contains(r'대전광역시 (?:동구|중구)')].copy()
area['행정동'] = area.adm_nm.str.split().str[2]; area['구'] = area.adm_nm.str.split().str[1]
D = pd.read_csv(O / 'dong_summary_v5.csv', dtype={'행정동코드': str}).set_index('행정동코드')
area = area.set_index('adm_cd2').join(D[['잠정', '선정_A', '선정_B', '선정_C', '선정_D']])
bl = pd.read_csv(O / 'buildings_lowaccess_v5.csv', dtype={'bld_id': str, '행정동코드': str})
low = bl[bl.저접근]; unk = bl[~bl.분석집합]
R = pd.read_csv(O / 'abc_results_v5.csv')
R = R[(R.집합 == '완전 사례(주 분석)') & (R.배차 == '(나) 기본') & (R.선정수 == 8)].copy(); R.index = R.방법.str.split().str[0]
gu = area.dissolve('구')
big = area.geometry.area / 1e6 > 7
x0, y0, x1, y1 = area[~big].total_bounds; pad = 600
zoom = (x0 - pad, y0 - pad, x1 + pad, y1 + pad)
panels = [('A', 'A 정류장 공급량', '인구 1만 명당 정류장이 적은 동'), ('B', 'B 동 평균 점수', '평균 접근성 점수가 낮은 동'),
          ('C', 'C 저접근 비율', '저접근 건물 비율이 높은 동'), ('D', 'D 저접근 건물 수 (탐색 비교)', '저접근 건물이 많은 동 — 계획 밖')]
fig, axes = plt.subplots(2, 4, figsize=(24, 14), gridspec_kw=dict(height_ratios=[1.05, 1]))
for j, (k, title, sub) in enumerate(panels):
    sel = area[f'선정_{k}'].astype(bool)
    cap = low[low[f'포착_{k}']]; mis = low[~low[f'포착_{k}']]
    for i, ax in enumerate(axes[:, j]):
        area.plot(ax=ax, color='white', edgecolor='#c9c8c2', linewidth=0.5)
        area[sel].plot(ax=ax, color=FILL, edgecolor=INK2, linewidth=1.1)
        gu.boundary.plot(ax=ax, color=INK2, linewidth=1.0)
        s = 1.4 if i == 0 else 4
        ax.scatter(unk.x, unk.y, s=s * 1.6, facecolors='none', edgecolors=UNK, linewidths=0.35, alpha=0.6)
        ax.scatter(mis.x, mis.y, s=s, c=MISS, alpha=0.75, linewidths=0)
        ax.scatter(cap.x, cap.y, s=s, c=CAP, alpha=0.9, linewidths=0)
        lab = area[sel & big] if i == 0 else area[sel & ~big]
        for code, r in lab.iterrows():
            p = r.geometry.representative_point()
            ax.annotate(r.행정동 + ('*' if r.잠정 else ''), (p.x, p.y), fontsize=9.5 if i else 9, ha='center', va='center', color=INK,
                        bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.85))
        ax.set_axis_off(); ax.set_aspect('equal')
        if i == 0:
            ax.add_patch(Rectangle((zoom[0], zoom[1]), zoom[2] - zoom[0], zoom[3] - zoom[1], fill=False, ec=INK2, lw=0.8, ls='--'))
            rr = R.loc[k]
            ax.set_title(f'{title}\n({sub})\n포착률 {rr.포착률:.1%} · 집중도 {rr.집중도:.1%} · 놓침 {int(rr.미포착):,}동 · 면적 {rr.선정동_면적비율:.0%}',
                         fontsize=11.5, color=INK)
        else:
            ax.set_xlim(zoom[0], zoom[2]); ax.set_ylim(zoom[1], zoom[3])
            ax.set_title('시가지 확대(위 점선 상자)', fontsize=10, color=INK2)
handles = [Line2D([], [], marker='o', ls='', color=CAP, ms=7, label='저접근 건물 — 고른 동 안(포착)'),
           Line2D([], [], marker='o', ls='', color=MISS, ms=7, label='저접근 건물 — 고른 동 밖(놓침, 자료 확인된 건물)'),
           Line2D([], [], marker='o', ls='', mfc='none', mec=UNK, ms=7, label='미확인 건물 — 주 분석에서 제외(저접근 여부 판정 안 함)'),
           Patch(fc=FILL, ec=INK2, label='고른 8개 동')]
fig.legend(handles=handles, loc='lower center', ncol=4, fontsize=11, frameon=False)
fig.suptitle('대전 동구·중구 — 동 고르기 기준별 8개 동과 저접근 주거건물 (v5, 완전 사례 33,809동 중 0.8m/s 점수 하위 20% = 6,762동)\n'
             '* = 미확인 건물이 주거건물의 10% 이상인 "잠정" 동 · 빈 곳은 접근성이 좋은 곳이 아니라 저접근 건물이 없거나(흰 바탕) 미확인(청록 원)인 곳',
             fontsize=13, color=INK)
plt.tight_layout(rect=(0, 0.03, 1, 0.94))
plt.savefig(O / 'abc_map_v5.png', dpi=130)
print('saved')
