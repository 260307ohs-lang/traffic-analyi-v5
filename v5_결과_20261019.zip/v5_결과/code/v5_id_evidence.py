# 미연결 9개 ID: ID마다 근거를 자료에서 다시 계산하고 '대체 후보 / 미확인'으로 표기 (v5)
# 대체 후보 = ① 현행 ID가 공식 시간표의 노선·갈래로 연결됨 ② 기점·종점 정류장 이름 같음 ③ 정류장 95% 이상이 현행 ID 경로 안
#            (보조) 같은 시간대 관측에서 현행 ID는 관측, 미연결 ID는 0회
#   → 유사 경로를 찾는 규칙이며 공식 구 ID→신 ID 대응 증거는 아님. 본 분석에서는 현행 ID만 사용
#   → '확인'으로 바꾸는 조건: 공식 대응표·노선 개편 공지, 또는 회차 단위 동등성
# 폐지 확인 = 공식 폐지 문서가 있을 때만 / 중복 확인 = 정류장 순서가 완전히 같은 다른 ID가 있을 때만 / 나머지 = 미확인
from pathlib import Path
import pandas as pd, numpy as np, geopandas as gpd
from scipy.spatial import cKDTree
ROOT = Path(__file__).resolve().parents[1]
R = ROOT / 'data/api/daejeon_bus_20261019'; O3 = ROOT / 'out/v3'; O = ROOT / 'out/v5'
rs = pd.read_csv(R / 'route_stops.csv', dtype=str).apply(lambda s: s.str.strip()); rs['seq'] = pd.to_numeric(rs.BUSSTOP_SEQ)
rt = pd.read_csv(R / 'routes.csv', dtype=str).apply(lambda s: s.str.strip())
TB = pd.read_csv(O3 / 'route_table.csv', dtype=str)
used = set(TB[TB.사용 == 'True'].ROUTE_CD)
no = dict(zip(rt.ROUTE_CD, rt.ROUTE_NO))
seq = {rc: list(q.sort_values('seq').BUS_STOP_ID) for rc, q in rs.groupby('ROUTE_CD')}
nm = rs.drop_duplicates('BUS_STOP_ID').set_index('BUS_STOP_ID').BUSSTOP_NM
served = set(rs[rs.ROUTE_CD.isin(used)].BUS_STOP_ID)
arr = pd.read_csv(ROOT / 'data/colab_in/arrive_check2/arrive_check_20261019_0545/arrivals.csv', dtype=str)
OBS = {"30300097": ["14630", "21410"], "30300117": ["12550", "12560"], "30300142": ["12550", "12560", "12960"],
       "30300143": ["12960"], "30300136": ["14630", "21410", "21680"], "30300116": ["21410", "21680"],
       "30300109": ["21680", "21690"], "69690109": ["21680", "21690"], "30300139": ["11810", "14630"]}
TTNAME = {'30300147': '33번(범례 주황=사정공원방향 4회)', '30300118': '71번(71-1 구간)', '30300119': '71번(71-2 구간)',
          '69690116': '2002번(202번(2002번) 공동 블록)', '30300137': '20번'}
bp = gpd.read_file(O3 / 'buildings_points.gpkg'); XY = np.c_[bp.x, bp.y]
st = pd.read_csv(O / 'buildings_scored_v5tt.csv', dtype={'bld_id': str}, usecols=['bld_id', '자료상태']).set_index('bld_id').자료상태
g = gpd.GeoDataFrame(rs, geometry=gpd.points_from_xy(pd.to_numeric(rs.GPS_LONG), pd.to_numeric(rs.GPS_LATI)), crs=4326).to_crs(5186)
rs['x'] = g.geometry.x; rs['y'] = g.geometry.y
JUDGE = {'30300097': ('대체 후보', '30300147'), '30300117': ('대체 후보', '30300118'), '30300142': ('대체 후보', '30300118'),
         '30300143': ('대체 후보', '30300119'), '30300116': ('대체 후보', '69690116'),
         '30300136': ('미확인', ''), '30300109': ('미확인', ''), '69690109': ('미확인', ''), '30300139': ('미확인', '')}
rows = []
for rc, (j, rep) in JUDGE.items():
    s = seq[rc]; S0 = set(s)
    cont = sorted(((len(S0 & set(seq[c])) / len(S0), c) for c in used), reverse=True)
    best_c, best = cont[0]
    cur = rep or best; cs = seq[cur]
    out = [x for x in dict.fromkeys(s) if x not in set(cs)]
    a = arr[arr.req_stop.isin(OBS[rc])]; n_poll = 30 * len(OBS[rc])
    obs_cur = int(a[a.ROUTE_CD == cur].groupby(['poll_time', 'req_stop']).ngroups)
    p = rs[rs.ROUTE_CD == rc][['x', 'y']].values
    d, _ = cKDTree(p).query(XY, distance_upper_bound=0.8 * 60 * 8 / 1.3)
    near = pd.Series(np.isfinite(d), index=bp.bld_id.values)
    rows.append(dict(ROUTE_CD=rc, 경유정류장=len(s), 기점=nm[s[0]], 종점=nm[s[-1]], 비교ID=cur, 비교노선=no.get(cur, ''),
                     비교ID_시간표=TTNAME.get(cur, ''), 정류장포함률=round(len(S0 & set(cs)) / len(S0), 3),
                     최대포함노선=f"{no.get(best, best)}({best}) {best_c:.0%}",
                     기종점이름같음={nm[s[0]], nm[s[-1]]} == {nm[cs[0]], nm[cs[-1]]}, 기종점ID같음={s[0], s[-1]} == {cs[0], cs[-1]},
                     비교ID에없는정류장=', '.join(f"{nm[x]}({'다른 노선 있음' if x in served else '현행 노선 없음'})" for x in out),
                     정류장순서완전히같은ID=','.join(c for c in seq if c != rc and seq[c] == s) or '없음',
                     관측_미연결ID=f"{int((a.ROUTE_CD == rc).sum())}/{n_poll}", 관측_비교ID=f'{obs_cur}/{n_poll}',
                     도보권건물_08=int(near.sum()), 도보권중_미확인아닌건물=int((near & (st.reindex(near.index) != '미확인(미연결 ID)')).sum()),
                     판정=j, 대체후보ID=rep,
                     본분석처리=('현행 ID만 사용(옛 ID는 점수에 넣지 않음), 도보권 건물은 "대체 후보 도보권"으로 표시하고 주 분석에 포함'
                               if j == '대체 후보' else '도보권 건물을 미확인으로 두고 주 분석(완전 사례)에서 제외'),
                     확인으로바꾸는조건=('공식 대응표·노선 개편 공지 또는 회차 단위 동등성' if j == '대체 후보' else '공식 운행 여부 확인(시 문의·개편 공지 등)')))
E = pd.DataFrame(rows)
E.to_csv(O / 'unlinked_id_judgement_v5.csv', index=False, encoding='utf-8-sig')
pd.set_option('display.width', 250)
print(E[['ROUTE_CD', '비교노선', '정류장포함률', '기종점이름같음', '기종점ID같음', '관측_미연결ID', '관측_비교ID', '도보권건물_08', '도보권중_미확인아닌건물', '판정']].to_string(index=False))
