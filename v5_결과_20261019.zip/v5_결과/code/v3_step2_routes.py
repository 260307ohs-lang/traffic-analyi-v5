# 계획서 10장 2단계: 노선 복구 — 수집 검증, ID 연결, 중복 점검, 배차값 해석, 미연결 분류, 완료표
# 무엇을: 노선표(배차)와 경유정류장표(정류장 순서·좌표)를 노선 ID로 연결하고, 빠지거나 겹치는 노선을 찾는다.
# 왜:     잘못 연결되면 건물 점수가 부풀거나(중복) 낮아진다(누락).
# 볼 것:  완료표의 항목별 건수, 노선 정리표의 '상태'.
import re, json
import numpy as np, pandas as pd, geopandas as gpd
from pathlib import Path as _P
S = str(_P(__file__).resolve().parents[1])   # 프로젝트 폴더(이 파일이 있는 code/의 상위)
R = S + '/data/api/daejeon_bus_20261019'   # 10/19 재수집본(쪽별 검증 완료)
O = S + '/out/v3'

rt = pd.read_csv(R + '/routes.csv', dtype=str).apply(lambda s: s.str.strip())       # ID는 문자열로 (앞자리 0 보존)
rs = pd.read_csv(R + '/route_stops.csv', dtype=str).apply(lambda s: s.str.strip())
rs['seq'] = pd.to_numeric(rs.BUSSTOP_SEQ)

# ① 수집 검증: API 머리글의 전체 건수(itemCnt) = 받은 건수
clog = json.load(open(R + '/collect_log.json', encoding='utf-8'))
chk = [(lg['자료'], lg['전체건수'], lg['받은건수'], lg['실패쪽'], lg['완전'], lg['시작']) for lg in clog['수집']]
assert all(c[4] for c in chk) and chk[0][2] == len(rt) and chk[1][2] == len(rs)
print('① 수집 검증 (자료, 전체건수, 받은건수, 실패쪽, 완전, 수집시작 UTC):', chk)
iq = pd.read_csv(R + '/individual_query.csv', dtype=str).fillna('')
tago = pd.read_csv(R + '/tago_check.csv', dtype=str)
print('   개별 조회(getRouteInfo): 대조', int((iq.구분.str.startswith('대조') & (iq.결과수 != '0')).sum()), '/', int(iq.구분.str.startswith('대조').sum()),
      '결과 있음 | 미연결', int((~iq.구분.str.startswith('대조') & (iq.결과수 != '0')).sum()), '/', int((~iq.구분.str.startswith('대조')).sum()), '결과 있음')

# ② ID 형식
bad_id = [(n, d.ROUTE_CD[~d.ROUTE_CD.str.fullmatch(r'\d{8}')].tolist()) for n, d in (('노선표', rt), ('경유표', rs))]
print('② 8자리 숫자가 아닌 노선 ID:', bad_id)

# ③ 경유정류장 수·순서: 노선표의 BUSSTOP_CNT 와 경유표 행 수, 순번 1..n 연속 여부
cnt = rs.groupby('ROUTE_CD').agg(행수=('seq', 'size'), 최소=('seq', 'min'), 최대=('seq', 'max'), 고유순번=('seq', 'nunique'))
m = rt.set_index('ROUTE_CD').join(cnt)
m['BUSSTOP_CNT'] = pd.to_numeric(m.BUSSTOP_CNT)
gap = m[(m.행수 != m.BUSSTOP_CNT) | (m.최소 != 1) | (m.최대 != m.행수) | (m.고유순번 != m.행수)]
print('③ 정류장 수·순번이 맞지 않는 노선:', len(gap), gap[['ROUTE_NO', 'BUSSTOP_CNT', '행수', '최소', '최대']].to_dict('index') if len(gap) else '')

# ④ 중복 등록: 정류장 순서와 배차·첫막차까지 모두 같은 노선 ID
seqs = {rc: tuple(q.sort_values('seq').BUS_STOP_ID) for rc, q in rs.groupby('ROUTE_CD')}
sched_cols = ['ALLO_INTERVAL', 'ALLO_INTERVAL_SAT', 'ALLO_INTERVAL_SUN', 'ORIGIN_START', 'ORIGIN_END']
rt['sig'] = [(seqs.get(rc), tuple(r[c] for c in sched_cols)) for rc, r in zip(rt.ROUTE_CD, rt.to_dict('records'))]
dup_groups = [list(g.ROUTE_CD) for _, g in rt.groupby('sig') if len(g) > 1]
print('④ 완전히 같은 노선(중복 등록):', dup_groups, [rt.set_index('ROUTE_CD').ROUTE_NO[g[0]] for g in dup_groups])
drop_dup = {g2: g[0] for g in dup_groups for g2 in g[1:]}          # 앞의 ID(대전 코드)를 남긴다
# 참고: 정류장 집합이 90% 이상 겹치는 노선표 안 쌍 (방향·분기 후보, 제외하지 않음)
sets = {rc: set(s) for rc, s in seqs.items()}
near = []
codes = list(rt.ROUTE_CD)
for i, a in enumerate(codes):
    for b in codes[i + 1:]:
        j = len(sets[a] & sets[b]) / len(sets[a] | sets[b])
        if j >= 0.9 and not (a in drop_dup or b in drop_dup):
            near.append((a, b, round(j, 3)))
no = dict(zip(rt.ROUTE_CD, rt.ROUTE_NO))
print('   참고: 노선표 안에서 정류장 90% 이상 겹치는 쌍:', [(no[a], no[b], j) for a, b, j in near])

# ⑤ 배차값 해석
for c in ['ALLO_INTERVAL', 'ALLO_INTERVAL_SAT', 'ALLO_INTERVAL_SUN']:
    v = pd.to_numeric(rt[c], errors='coerce')
    print(f'⑤ {c}: 숫자 아님 {int(v.isna().sum())}, 0 {int((v == 0).sum())}, 범위 {v.min():.0f}~{v.max():.0f}분')
def minute(t):
    t = str(t).zfill(4); return int(t[:2]) * 60 + int(t[2:])
span = rt.ORIGIN_END.map(minute) - rt.ORIGIN_START.map(minute)
span = span.where(span >= 0, span + 1440)
h = pd.to_numeric(rt.ALLO_INTERVAL)
k = span / h
long = h >= 60
print(f'   배차 60분 이상 {int(long.sum())}개: (첫차~막차)/배차 가 정수에서 벗어난 정도 중앙값 {np.median(np.abs(k[long] - k[long].round())):.2f}'
      f' (우연이면 약 0.25) → 첫차~막차 평균 간격일 가능성(추정)')
weekend_off = rt[(pd.to_numeric(rt.ALLO_INTERVAL_SAT) == 0)].ROUTE_NO.tolist()
print('   주말 배차 0 (주말 첫차도 0000 → 주말 비운행 해석):', weekend_off)

# ⑥ 미연결 노선 분류 (정류장 비교 근거)
adm = gpd.read_file(S + '/data/ext/admdong.geojson').to_crs(5186)
area = adm[adm.adm_nm.str.contains(r'대전광역시 (?:동구|중구)')]
st = rs.drop_duplicates('BUS_STOP_ID')
g = gpd.GeoDataFrame(st[['BUS_STOP_ID']], geometry=gpd.points_from_xy(pd.to_numeric(st.GPS_LONG), pd.to_numeric(st.GPS_LATI)), crs=4326).to_crs(5186)
in_area = set(g[g.within(area.union_all())].BUS_STOP_ID)
in_buf = set(g[g.within(area.union_all().buffer(1000))].BUS_STOP_ID)
master = set(rt.ROUTE_CD) - set(drop_dup)
served_by_master = set(rs[rs.ROUTE_CD.isin(master)].BUS_STOP_ID)
miss = sorted(set(rs.ROUTE_CD) - set(rt.ROUTE_CD))
OBS_STOPS = {"30300097": ["14630", "21410"], "30300117": ["12550", "12560"], "30300142": ["12550", "12560", "12960"],
             "30300143": ["12960"], "30300136": ["14630", "21410", "21680"], "30300116": ["21410", "21680"],
             "30300109": ["21680", "21690"], "69690109": ["21680", "21690"], "30300139": ["11810", "14630"]}
# ID별 판정 (2026-10-19 수정): 9개를 한꺼번에 '현행 노선 아님'으로 정하지 않는다.
#   대체 후보 = ① 현행 ID가 공식 시간표의 노선·갈래로 연결됨 ② 기점·종점 정류장 이름 같음 ③ 정류장 95% 이상이 현행 ID 경로 안
#              (유사 경로를 찾는 규칙일 뿐 공식 구 ID→신 ID 대응 증거가 아님. 공식 대응·개편 공지나 회차 단위 동등성이 확보되면 '확인'으로 바꿈)
#              본 분석에서는 현행 ID만 사용하고, 후보를 미확인으로 바꾼 민감도를 따로 계산(v5_abc.py)
#                 (보조) 같은 시간대 관측에서 현행 ID는 관측, 미연결 ID는 0회
#   폐지 확인 = 공식 폐지 문서가 있을 때만(현재 0) / 중복 확인 = 정류장 순서가 완전히 같은 다른 ID가 있을 때만(현재 0) / 그 밖 = 미확인
#   자세한 근거표: v4_id_evidence.py → unlinked_id_judgement_v4.csv
CLASS = {  # (판정, 대체 ID 또는 가장 비슷한 노선 ID, 근거 요약)
    '30300097': ('대체 후보', '30300147', '33-1과 기점·종점 같음(이름·ID), 정류장 97%가 33-1 경로 안(빠진 2곳 구완동·서대전네거리역2번출구는 현행 노선 없음)'),
    '30300117': ('대체 후보', '30300118', '71-1과 기점·종점 같음(이름·ID), 정류장 100%가 71-1 경로 안'),
    '30300142': ('대체 후보', '30300118', '71-1과 기점·종점 같음(이름·ID), 정류장 100%가 71-1 경로 안'),
    '30300143': ('대체 후보', '30300119', '71-2와 기점·종점 같음(이름·ID), 정류장 100%가 71-2 경로 안'),
    '30300116': ('대체 후보', '69690116', '2002번과 기점·종점 이름 같음(ID는 다름), 정류장 97%가 2002 경로 안; 2002번은 시간표 202번(2002번) 공동 블록에 있음'),
    '30300136': ('미확인', '30300137', '20번 경로와 정류장 93% 겹치지만 기점(기성동기점지)이 다르고, 기성동기점지·서대전네거리역2번출구는 현행 노선 없음'),
    '30300109': ('미확인', '', '서남부터미널~계룡 입암리 왕복, 69690109와 정류장 70개 공통이지만 순서·회차지(입암리마을회관종점)가 달라 중복 아님'),
    '69690109': ('미확인', '', '서남부터미널~계룡 입암리 왕복, 30300109와 정류장 70개 공통이지만 회차지(입암리수변공원종점)·새터 경유가 달라 중복 아님'),
    '30300139': ('미확인', '', '대전역동광장 순환, 가장 많이 겹치는 노선(611번)도 62%; 계족산(황토길)은 현행 노선 없음'),
}
rows = []
for rc in sorted(set(rs.ROUTE_CD)):
    q = rs[rs.ROUTE_CD == rc]
    ids = set(q.BUS_STOP_ID)
    r = dict(ROUTE_CD=rc, ROUTE_NO=no.get(rc, ''), 경유정류장=len(q), 연구지역_경계안_정류장=len(ids & in_area),
             연구지역_1km안_정류장=len(ids & in_buf))
    if rc in drop_dup:
        r.update(상태='제외: 중복 등록', 근거=f'{drop_dup[rc]}({no[drop_dup[rc]]})와 정류장 순서·배차·첫막차 동일', 사용=False)
    elif rc in master:
        rr = rt.set_index('ROUTE_CD').loc[rc]
        r.update(상태='사용', 근거='노선표·경유표 연결됨', 사용=True, 평일배차=rr.ALLO_INTERVAL, 토배차=rr.ALLO_INTERVAL_SAT,
                 일배차=rr.ALLO_INTERVAL_SUN, 첫차=rr.ORIGIN_START, 막차=rr.ORIGIN_END, 유형코드=rr.ROUTE_TP)
    else:
        if r['연구지역_1km안_정류장'] == 0:
            r.update(상태='미연결: 연구지역 밖', 근거='동구·중구+1km 안에 정류장 없음 | 개별조회 결과 없음(10/19)', 사용=False)
        else:
            c, parent, why = CLASS[rc]
            only = len(ids & in_buf - served_by_master)
            tg = tago.set_index('ROUTE_CD')['TAGO 노선 페이지'].get(rc, '미확인')
            n_ok = 30 * len(OBS_STOPS[rc])          # 관측: 정류장마다 30회 조회 모두 성공 (오류 0)
            tt_note = ('운송조합 시간표(2026-08-18) 202번(2002번) 공동 블록의 2002번 = 현행 ID 69690116' if rc == '30300116' else
                       f'운송조합 시간표(2026-08-18)의 {no.get(parent)}번 계열 = 현행 ID {parent}' if c == '대체 후보' else
                       '운송조합 시간표(2026-08-18)에서 이 ID에 해당하는 노선을 찾지 못함')
            state = f'대체 후보 → {parent}({no.get(parent)}): 본 분석은 현행 ID만 사용' if c == '대체 후보' else '미확인: 현행 운행 여부 공식 확인 안 됨'
            r.update(상태=state, 판정=c, 정류장비교=why, 겹치는노선=no.get(parent, ''), 사용=False,
                     연구지역정류장중_다른노선없는곳=only,
                     근거=why + ' | [공식] 노선표 전체 목록·개별 조회(2026-10-19 14:20 KST)에 없음 | [공식] ' + tt_note +
                          f' | [보조] 2026-10-19 14:45~15:43 KST 도착정보 관측: 지나는 관측 정류장 성공 조회 {n_ok}회 중 0회 관측'
                          ' | [참고·비공식] TAGO 옮김 민간 사이트에 노선 ' + tg)
    rows.append(r)
T = pd.DataFrame(rows)
T.to_csv(O + '/route_table.csv', index=False, encoding='utf-8-sig')
print('\n⑥ 노선 정리표 상태별:', T.상태.value_counts().to_dict())

# 완료표는 v4_completion.py에서 새로 만든다 (시간표 v4·점수 v4 결과를 써야 해서). 아래는 v3 기록용으로만 남김.
aff = T[T.상태.str.startswith('대체 후보') | T.상태.str.startswith('미확인')]
print('\n미연결(연구지역) 노선의 동구·중구+1km 정류장 중 사용 노선이 하나도 안 서는 곳:',
      aff[['ROUTE_CD', '연구지역_1km안_정류장', '연구지역정류장중_다른노선없는곳']].values.tolist())
