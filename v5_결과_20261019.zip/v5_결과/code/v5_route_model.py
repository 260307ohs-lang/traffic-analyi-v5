# 노선 모형 v5: 노선·정류장마다 배차 값 여러 개를 함께 만든다.
#   h_tt     (나) 기본값: 공식 시간표 '기점 출발' 회차의 첫차~막차 평균 간격 = (막차−첫차)÷(회차−1)
#            · 기점 칸에 장소 이름이 붙은 회차(예: '서대전IC 5:40')는 기점 출발이 아니므로 뺀다 (v4에서는 넣었음)
#            · 33번: 시간표 범례 색(주황=사정공원방향=33-1, 초록=산성초교방향=33-2)으로 회차를 갈래에 배정
#            · 61·71·72번: 회차지 이름·회차 표시·지원 운행·미운행 메모로 구간별 회차 (v4와 같음)
#   h_v4fix33 검토자 대조용: v4 값에서 33번만 색으로 고친 값 (기점 칸 장소 회차 포함)
#   h_api    (가) 출처 민감도: 시간표와 1:1로 연결된 단일 노선만 노선표 배차로 바꾸고, 갈래 계열은 (나)와 같은 구조
#   h_best / h_worst  근사 범위: 정류장이 기점 방향인지 회차지 방향인지, 중간 출발 회차가 그 정류장을 지나는지 모르므로
#            {기점 출발(중간 출발 일부 포함)}, {회차지 출발(중간 출발 일부 포함)} 회차 집합들의 평균 간격 중 가장 짧은/긴 값
# 시간표에 없는 노선(24개)은 모든 값이 노선표 평일 배차(ALLO_INTERVAL)
import json, itertools
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
R = ROOT / 'data/api/daejeon_bus_20261019'; O3 = ROOT / 'out/v3'; O = ROOT / 'out/v5'
rt = pd.read_csv(R / 'routes.csv', dtype=str).apply(lambda s: s.str.strip())
rs = pd.read_csv(R / 'route_stops.csv', dtype=str).apply(lambda s: s.str.strip()); rs['seq'] = pd.to_numeric(rs.BUSSTOP_SEQ)
TB = pd.read_csv(O3 / 'route_table.csv', dtype=str)
used = TB[TB.사용 == 'True'].ROUTE_CD.tolist()
TRIPS = json.load(open(O / 'tt_trips_v5.json', encoding='utf-8'))
SCAN = pd.read_csv(O / 'tt_scan_blocks_v5.csv')
def trips_of(name):
    k = [k for k in TRIPS if k.split('|')[0] == name and k.split('|')[1] in ('평일', 'ALL')]
    assert len(k) == 1, (name, k)
    return TRIPS[k[0]], k[0]
def eff_of(key):
    nm, day, row = key.split('|')
    s = SCAN[(SCAN.시간표노선 == nm) & (SCAN.요일 == day) & (SCAN.블록행 == int(row))]
    return str(s.시행일.iloc[0]) if len(s) else ''
def m(t):
    t = str(t).zfill(4); v = int(t[:2]) * 60 + int(t[2:]); return v + 1440 if v < 180 else v
R0 = rt.set_index('ROUTE_CD')
api_h = pd.to_numeric(R0.ALLO_INTERVAL); api_f = R0.ORIGIN_START.map(m); api_l = R0.ORIGIN_END.map(m)
def iv(times):
    t = sorted(times); return (t[-1] - t[0]) / (len(t) - 1) if len(t) > 1 else np.nan
def hm(x): return f'{int(x // 60) % 24:02d}:{int(x % 60):02d}'
def tt_name(rc):
    no, tp = R0.ROUTE_NO[rc], R0.ROUTE_TP[rc]
    return f'급행{no}번' if tp == '1' else f'첨단{no}번' if tp == '6' else f'{no}번'
def sets(tl, pick=lambda x: True):
    """선택한 회차들의 기점/회차지 출발 시각: 정규(시각만) / 중간 출발(장소 글자 붙음)"""
    t = [x for x in tl if pick(x)]
    return dict(O_reg=[x['기점출발'] for x in t if x['기점출발'] is not None and not x['기점글자']],
                O_mid=[x['기점출발'] for x in t if x['기점출발'] is not None and x['기점글자']],
                I_reg=[x['회차출발'] for x in t if x['회차출발'] is not None and not x['회차글자']],
                I_mid=[x['회차출발'] for x in t if x['회차출발'] is not None and x['회차글자']])
def bounds(groups):
    """groups: [(정규 목록, 중간 출발 목록), ...] → 가능한 회차 집합들의 평균 간격 최소·최대"""
    c = []
    for reg, mid in groups:
        if not reg and not mid: continue
        for k in range(len(mid) + 1):
            for S in itertools.combinations(mid, k):
                v = iv(reg + list(S))
                if np.isfinite(v): c.append(v)
    return (min(c), max(c)) if c else (np.nan, np.nan)
FAM = {'F33': ['30300147', '30300148'], 'F61': ['30300027', '30300028'], 'F71': ['30300118', '30300119'],
       'F72': ['30300120', '30300098'], 'FM1': ['30300154', '30300156']}
in_fam = {rc: f for f, l in FAM.items() for rc in l}
stops_of = {rc: list(dict.fromkeys(q.sort_values('seq').BUS_STOP_ID)) for rc, q in rs.groupby('ROUTE_CD')}
names_of = {rc: set(q.BUSSTOP_NM) for rc, q in rs.groupby('ROUTE_CD')}
nm = rs.drop_duplicates('BUS_STOP_ID').set_index('BUS_STOP_ID').BUSSTOP_NM
rows, routes = [], []
def add(route, label, sid, seg, src, eff, n_tt, h_tt, h_v4, h_api, hb, hw, note=''):
    rows.append(dict(모형노선=route, 표시=label, BUS_STOP_ID=sid, 정류장명=nm.get(sid, ''), 구간=seg, 출처_tt=src, 시행일_tt=eff,
                     회차_tt=n_tt, h_tt=h_tt, h_v4fix33=h_v4, h_api=h_api, h_best=hb, h_worst=hw, 비고=note))

# 1) 단일 노선
for rc in used:
    if rc in in_fam: continue
    name = tt_name(rc); lab = f'{R0.ROUTE_NO[rc]} ({rc})'
    ha = float(api_h[rc])
    try:
        tl, key = trips_of(name)
    except AssertionError:
        tl = None
    if tl is None:
        src, eff = '노선표(시간표 미수록)', '적용일 미표기(2026-10-19 수집)'
        n = round((api_l[rc] - api_f[rc]) / ha + 1, 2)
        vals = (n, ha, ha, ha, ha, ha); note = ''
        routes.append(dict(모형노선=rc, 표시=lab, 시간표=name, 출처=src, 시행일=eff, 기점정규=np.nan, 기점중간=np.nan, 회차지정규=np.nan, 회차지중간=np.nan,
                           h_tt=ha, h_v4=ha, h_api=ha, h_best=ha, h_worst=ha, 중간출발='', 비고=''))
    else:
        st = sets(tl); eff = eff_of(key)
        h_tt = iv(st['O_reg']); h_v4 = iv(st['O_reg'] + st['O_mid'])
        hb, hw = bounds([(st['O_reg'], st['O_mid']), (st['I_reg'], st['I_mid'])])
        mids = [f"{x['셀']} {x['기점글자']} {hm(x['기점출발'])}(기점쪽)" for x in tl if x['기점글자'] and x['기점출발'] is not None] + \
               [f"{x['셀']} {x['회차글자']} {hm(x['회차출발'])}(회차지쪽)" for x in tl if x['회차글자'] and x['회차출발'] is not None]
        src = '시간표'; vals = (len(st['O_reg']), h_tt, h_v4, ha, hb, hw)
        note = ('중간 출발 제외: ' + '; '.join(mids)) if mids else ''
        routes.append(dict(모형노선=rc, 표시=lab, 시간표=name, 출처=src, 시행일=eff, 기점정규=len(st['O_reg']), 기점중간=len(st['O_mid']),
                           회차지정규=len(st['I_reg']), 회차지중간=len(st['I_mid']), h_tt=h_tt, h_v4=h_v4, h_api=ha, h_best=hb, h_worst=hw,
                           중간출발='; '.join(mids), 비고=''))
    for sid in stops_of[rc]:
        add(rc, lab, sid, '전 구간', src, eff, *vals, note=note)

# 2) 갈래 계열: 구간별 회차 집합 (기점 방향 / 회차지 방향)
def famrows(f, lab, eff, segs, seg_of):
    """segs: {구간: dict(tt=기점 출발 목록(기본값), out=(정규, 중간), inn=(정규, 중간))}"""
    A, Bid = FAM[f]
    for sid in dict.fromkeys(stops_of[A] + stops_of[Bid]):
        on = [i for i in FAM[f] if sid in set(stops_of[i])]
        seg = seg_of(sid, on); s = segs[seg]
        h = iv(s['tt']); hb, hw = bounds([s['out'], s['inn']])
        add(f, lab, sid, seg, s.get('src', '시간표(구간별 회차)'), eff, len(s['tt']), h, s.get('v4', h), h, hb, hw, s.get('note', ''))
    for seg, s in segs.items():
        routes.append(dict(모형노선=f, 표시=lab, 시간표=lab.split('(')[0], 출처='시간표(구간별 회차)', 시행일=eff, 구간=seg,
                           기점정규=len(s['out'][0]), 기점중간=len(s['out'][1]), 회차지정규=len(s['inn'][0]), 회차지중간=len(s['inn'][1]),
                           h_tt=iv(s['tt']), h_v4=s.get('v4', iv(s['tt'])), h_api=iv(s['tt']), h_best=bounds([s['out'], s['inn']])[0],
                           h_worst=bounds([s['out'], s['inn']])[1], 중간출발='', 비고=s.get('note', '')))

# F33: 범례 색으로 갈래 배정. 범례 글자의 장소가 어느 ID 경로에 있는지로 ID를 정한다(사정공원 → 33-1, 산성초교 → 33-2)
t33, k33 = trips_of('33번')
leg = json.loads(SCAN[(SCAN.시간표노선 == '33번')].범례.iloc[0])
place = {'사정공원방향': '사정공원', '산성초교방향': '산성초등학교'}
col2id = {}
for col, txt in leg.items():
    hit = [i for i in FAM['F33'] if place[txt] in names_of[i]]
    assert len(hit) == 1, (txt, hit); col2id[col] = hit[0]
assert all(x['기점색'] == x['회차색'] for x in t33)
b33 = {i: [x for x in t33 if col2id.get(x['기점색']) == i] for i in FAM['F33']}
assert sum(len(v) for v in b33.values()) == len(t33) == 7
all33 = sets(t33)
v4_33 = {'30300147': [6 * 60 + 15, 8 * 60 + 50, 18 * 60 + 15], '30300148': [11 * 60 + 15, 20 * 60 + 35]}   # v4가 쓰던 확정 회차
segs33 = {'공통': dict(tt=all33['O_reg'], out=(all33['O_reg'], all33['O_mid']), inn=(all33['I_reg'], all33['I_mid'])),
          '사정공원 갈래(33-1)': dict(tt=sets(b33['30300147'])['O_reg'], out=(sets(b33['30300147'])['O_reg'], []), inn=(sets(b33['30300147'])['I_reg'], []),
                                 note='시간표 범례 주황(사정공원방향) ' + ', '.join(hm(x['기점출발']) for x in b33['30300147'])),
          '산성초교 갈래(33-2)': dict(tt=sets(b33['30300148'])['O_reg'], out=(sets(b33['30300148'])['O_reg'], []), inn=(sets(b33['30300148'])['I_reg'], []),
                                 note='시간표 범례 초록(산성초교방향) ' + ', '.join(hm(x['기점출발']) for x in b33['30300148']))}
def seg33(sid, on):
    return '공통' if len(on) == 2 else ('사정공원 갈래(33-1)' if on[0] == '30300147' else '산성초교 갈래(33-2)')
famrows('F33', '33번(33-1·33-2 계열)', eff_of(k33), segs33, seg33)

# F61: 회차지 이름(냉천/천개동)으로 갈래. 첫 회차는 천개동 출발만 있음(06:30) → 회차지 방향에만 반영
t61, k61 = trips_of('61번')
nc = lambda x: '냉천' in str(x['회차칸']); cg = lambda x: '천개동' in str(x['회차칸'])
s61a, s61n, s61c = sets(t61), sets(t61, nc), sets(t61, cg)
segs61 = {'공통': dict(tt=s61a['O_reg'], out=(s61a['O_reg'], []), inn=(s61a['I_reg'], [])),
          '냉천 갈래': dict(tt=s61n['O_reg'], out=(s61n['O_reg'], []), inn=(s61n['I_reg'], [])),
          '천개동 갈래': dict(tt=s61c['O_reg'], out=(s61c['O_reg'], []), inn=(s61c['I_reg'], []), note='회차지 방향은 06:30 천개동 출발 1회 더 있음')}
def seg61(sid, on):
    return '공통' if len(on) == 2 else ('냉천 갈래' if on[0] == '30300027' else '천개동 갈래')
famrows('F61', '61번(61-1·61-2 계열)', eff_of(k61), segs61, seg61)

# F72: 특이사항 '3·4·5회차는 목상동~신탄진시장~용정초 구간 운행' → 30300098 갈래
t72, k72 = trips_of('72번')
s72a, s72b, s72o = sets(t72), sets(t72, lambda x: x['회차'] in ('3', '4', '5')), sets(t72, lambda x: x['회차'] not in ('3', '4', '5'))
segs72 = {'공통': dict(tt=s72a['O_reg'], out=(s72a['O_reg'], []), inn=(s72a['I_reg'], [])),
          '3·4·5회차 갈래': dict(tt=s72b['O_reg'], out=(s72b['O_reg'], []), inn=(s72b['I_reg'], [])),
          '그 밖 회차 갈래': dict(tt=s72o['O_reg'], out=(s72o['O_reg'], []), inn=(s72o['I_reg'], []))}
def seg72(sid, on):
    return '공통' if len(on) == 2 else ('3·4·5회차 갈래' if on[0] == '30300098' else '그 밖 회차 갈래')
famrows('F72', '72번(72·72-1 계열)', eff_of(k72), segs72, seg72)

# F71: 동신고 출발 6회는 전 구간, 직동편도지원(직동 15:00)은 직동~용호동, 직동 막차(21:40)는 남경마을~용호동 미운행
t71, k71 = trips_of('71번')
dong = lambda x: x['기점칸'] == '동신고'; jik = lambda x: str(x['기점칸']).startswith('직동지원'); last = lambda x: x['기점칸'] == '직동'
sd, sj, sl = sets(t71, dong), sets(t71, jik), sets(t71, last)
NAMGYEONG_YONGHO = {'남경마을', '신탄진과선교', '신탄진26통', '신탄진정수장', '용호동종점'}
segs71 = {'동신고~직동(71-1만)': dict(tt=sd['O_reg'], out=(sd['O_reg'], []), inn=(sd['I_reg'], sj['I_reg']),
                                   note='회차지 방향: 동신고 출발 회차의 귀로 6회 + 직동편도지원 귀로(15:40)가 동신고까지 가는지 미확인'),
          '직동~신탄진역(지원·막차 포함)': dict(tt=sd['O_reg'] + sj['O_reg'] + sl['O_reg'], out=(sd['O_reg'] + sj['O_reg'] + sl['O_reg'], []),
                                       inn=(sd['I_reg'] + sj['I_reg'] + sl['I_reg'], [])),
          '남경마을~용호동(직동 막차 미운행)': dict(tt=sd['O_reg'] + sj['O_reg'], out=(sd['O_reg'] + sj['O_reg'], []), inn=(sd['I_reg'] + sj['I_reg'], []))}
def seg71(sid, on):
    if len(on) == 1: return '동신고~직동(71-1만)'
    return '남경마을~용호동(직동 막차 미운행)' if nm.get(sid, '') in NAMGYEONG_YONGHO else '직동~신탄진역(지원·막차 포함)'
famrows('F71', '71번(71-1·71-2 계열)', eff_of(k71), segs71, seg71)

# FM1: 두 ID가 방향 → 정류장마다 그 방향 회차
tm, km = trips_of('M1번'); sm = sets(tm)
A, Bid = FAM['FM1']
for sid in dict.fromkeys(stops_of[A] + stops_of[Bid]):
    on = [i for i in FAM['FM1'] if sid in set(stops_of[i])]
    if on == [A]: t = sm['O_reg']; seg = '기점 방향'
    elif on == [Bid]: t = sm['I_reg']; seg = '회차지 방향'
    else: t = max(sm['O_reg'], sm['I_reg'], key=len); seg = '양방향'
    hb, hw = bounds([(sm['O_reg'], sm['O_mid']), (sm['I_reg'], sm['I_mid'])])
    add('FM1', 'M1번(방향별)', sid, seg, '시간표(방향별 회차)', eff_of(km), len(t), iv(t), iv(t), iv(t), hb, hw)

M = pd.DataFrame(rows)
M.to_csv(O / 'route_stop_headway_v5.csv', index=False, encoding='utf-8-sig')
RT = pd.DataFrame(routes); RT.to_csv(O / 'route_headway_v5.csv', index=False, encoding='utf-8-sig')
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 100)
print('모형 노선', M.모형노선.nunique(), '| 노선·정류장 행', len(M))
print('33번 색 배정:', {i: [hm(x['기점출발']) for x in v] for i, v in b33.items()})
g = M[M.모형노선.str.startswith('F')].groupby(['모형노선', '구간'], sort=False).agg(
    정류장=('BUS_STOP_ID', 'size'), 회차=('회차_tt', 'first'), h_tt=('h_tt', 'first'), h_v4fix33=('h_v4fix33', 'first'), h_best=('h_best', 'first'), h_worst=('h_worst', 'first'))
print(g.round(1).to_string())
s = RT[RT.출처 == '시간표']
print('\n단일 노선(시간표)', len(s), '| 기점 쪽 중간 출발이 있어 v4와 기본값이 달라진 노선', int((s.기점중간 > 0).sum()),
      '| 근사 범위 폭(h_worst/h_best−1) 중앙값 %.1f%%, 최대 %.1f%%' % (100 * (s.h_worst / s.h_best - 1).median(), 100 * (s.h_worst / s.h_best - 1).max()))
print(s[s.표시.str.startswith(('202 ', '2002 ', '501 ', '607 '))][['표시', '기점정규', '기점중간', '회차지정규', '회차지중간', 'h_tt', 'h_v4', 'h_best', 'h_worst']].round(2).to_string(index=False))
