# 시간표 v5 검사: 값만 읽던 v4와 달리 셀 채우기색까지 읽는다.
# 블록마다 ① 범례(색 칸 + 오른쪽 글자) ② 색이 칠해진 운행 칸 ③ 시각 외 글자가 든 운행 칸(중간 출발 등)
#          ④ 기점 출발 수 vs 회차지 출발 수 ⑤ 메모 를 모두 기록한다.
import re, json, datetime as dt
from pathlib import Path
import openpyxl, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
O = ROOT / 'out' / 'v5'; O.mkdir(parents=True, exist_ok=True)
wb = openpyxl.load_workbook(ROOT / 'data/timetable_in/timetable_20260818.xlsx', data_only=True)
ws = wb['시간표']
NR, NC = ws.max_row, ws.max_column
V = [[ws.cell(r, c).value for c in range(1, NC + 1)] for r in range(1, NR + 1)]
def color(r, c):
    f = ws.cell(r + 1, c + 1).fill          # r, c: 0부터
    if f is None or f.fill_type != 'solid': return None
    fg = f.fgColor
    if fg.type == 'rgb' and isinstance(fg.rgb, str) and fg.rgb not in ('00000000', 'FFFFFFFF'): return fg.rgb
    if fg.type == 'theme': return f'theme{fg.theme}{"+%.2f" % fg.tint if fg.tint else ""}'
    if fg.type == 'indexed' and fg.indexed not in (64, 65): return f'idx{fg.indexed}'
    return None
def tmin(v):
    if isinstance(v, dt.time): return v.hour * 60 + v.minute + v.second / 60
    if isinstance(v, dt.datetime): return v.hour * 60 + v.minute
    if isinstance(v, str):
        m = re.search(r'(\d{1,2}):(\d{2})', v)
        if m: return int(m.group(1)) * 60 + int(m.group(2))
    return None
def fix(t): return None if t is None else (t + 1440 if t < 180 else t)
def extra_text(v):
    """시각 칸에 시각 말고 다른 글자(장소 등)가 있으면 그 글자"""
    if not isinstance(v, str): return ''
    s = re.sub(r'\d{1,2}:\d{2}(:\d{2})?', '', v).strip(' \n()')
    return s.replace('\n', ' ')
H = [i for i, r in enumerate(V) if any(isinstance(c, str) and c.strip() == '~' for c in r)]
blocks, trips = [], {}
for b, i in enumerate(H):
    end = H[b + 1] if b + 1 < len(H) else NR
    hd = V[i]; name_raw, day = str(hd[0]).strip(), str(hd[19]).strip()
    gi = next(k for k in range(i + 1, min(end, i + 8)) if isinstance(V[k][0], str) and V[k][0].strip() == '구분')
    lab, names = V[gi], V[gi + 1]
    tcols = [j for j in range(1, len(lab)) if lab[j] is not None and re.match(r'^\s*\d', str(lab[j]))]
    rcol = next((j for j, c in enumerate(names) if isinstance(c, str) and c.strip() == '노선'), None)
    # 범례: 머리 행~구분 행 사이에서 색 칸 바로 오른쪽(1~2칸)에 글자가 있는 경우
    legend = {}
    for k in range(i + 1, gi):
        for j in range(NC):
            col = color(k, j)
            if col and V[k][j] in (None, ''):
                txt = next((V[k][jj] for jj in (j + 1, j + 2) if jj < NC and isinstance(V[k][jj], str) and V[k][jj].strip()), None)
                if txt: legend[col] = txt.strip()
    eff = next((next((x for x in V[k][1:6] if x not in (None, '')), None) for k in range(i, end)
                if isinstance(V[k][0], str) and V[k][0].strip() == '시행일'), None)
    eff = (eff.strftime('%Y.%m.%d') if isinstance(eff, (dt.date, dt.datetime)) else str(eff).strip().rstrip('.')) if eff else ''
    by_route = {}
    for k in range(gi + 2, end):
        r = V[k]
        if isinstance(r[0], str) and r[0].strip() == '시행일': break
        if not any(tmin(r[j]) is not None for j in tcols + [x + 1 for x in tcols] if j < NC): continue
        if rcol is not None and r[rcol] is None: continue
        rname = str(r[rcol]).strip() + '번' if rcol is not None else name_raw
        for j in tcols:
            o, t = r[j], (r[j + 1] if j + 1 < NC else None)
            if tmin(o) is None and tmin(t) is None: continue
            by_route.setdefault(rname, []).append(dict(
                셀=f'{openpyxl.utils.get_column_letter(j + 1)}{k + 1}', 차량행=k + 1, 회차=str(lab[j]).strip(), 기점칸=names[j],
                회차칸=names[j + 1] if j + 1 < len(names) else None,
                기점출발=fix(tmin(o)), 회차출발=fix(tmin(t)), 기점글자=extra_text(o), 회차글자=extra_text(t),
                기점색=color(k, j), 회차색=color(k, j + 1)))
    for rname, tl in by_route.items():
        key = f'{rname}|{day}|{i + 1}'; trips[key] = tl
        out = [x for x in tl if x['기점출발'] is not None]; inn = [x for x in tl if x['회차출발'] is not None]
        blocks.append(dict(블록행=i + 1, 블록명=name_raw, 요일=day, 시간표노선=rname, 시행일=eff,
                           기점=hd[7], 회차지=hd[11], 범례=json.dumps(legend, ensure_ascii=False) if legend else '',
                           기점출발수=len(out), 회차출발수=len(inn),
                           기점_글자칸=sum(bool(x['기점글자']) for x in out), 회차_글자칸=sum(bool(x['회차글자']) for x in inn),
                           색칸수=sum(bool(x['기점색']) + bool(x['회차색']) for x in tl),
                           글자예=' / '.join(dict.fromkeys(f"{x['셀']}:{x['기점글자'] or x['회차글자']}" for x in tl if x['기점글자'] or x['회차글자']))[:300]))
B = pd.DataFrame(blocks)
B.to_csv(O / 'tt_scan_blocks_v5.csv', index=False, encoding='utf-8-sig')
json.dump(trips, open(O / 'tt_trips_v5.json', 'w', encoding='utf-8'), ensure_ascii=False)
wk = B[B.요일.isin(['평일', 'ALL'])]
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 160)
print('블록', len(H), '| 평일·ALL 노선', wk.시간표노선.nunique())
print('\n[범례가 있는 블록]'); print(B[B.범례 != ''][['블록행', '시간표노선', '요일', '범례']].to_string(index=False))
print('\n[색 칸이 있는 평일·ALL 노선]'); print(wk[wk.색칸수 > 0][['블록행', '시간표노선', '요일', '색칸수', '범례']].to_string(index=False))
print('\n[시각 외 글자가 든 운행 칸 (평일·ALL)]'); print(wk[(wk.기점_글자칸 + wk.회차_글자칸) > 0][['블록행', '시간표노선', '기점출발수', '회차출발수', '기점_글자칸', '회차_글자칸', '글자예']].to_string(index=False))
print('\n[기점 출발 수 ≠ 회차지 출발 수 (평일·ALL)]'); print(wk[wk.기점출발수 != wk.회차출발수][['블록행', '시간표노선', '기점', '회차지', '기점출발수', '회차출발수']].to_string(index=False))
