# v5 결과 묶음: 상대 경로로 다시 실행할 수 있게 입력·코드·결과를 같은 폴더 구조로 담는다
import hashlib, shutil, zipfile, json
from pathlib import Path
import geopandas as gpd, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
STG = ROOT / 'out/pkg_v5/v5_결과'
if STG.exists(): shutil.rmtree(STG)
CODE = ['run_all.py', 'v3_step2_routes.py', 'v3_step3_buildings.py', 'v5_tt_scan.py', 'v5_route_model.py', 'v5_scores.py', 'v5_id_evidence.py',
        'v5_abc.py', 'v5_completion.py', 'v5_abc_map.py', 'v5_package.py']
INPUTS = [('data/api/daejeon_bus_20261019/routes.csv', '대전시 노선정보 API getRouteInfoAll, 2026-10-19 14:17~14:20 KST 수집(쪽별 건수 검증)'),
          ('data/api/daejeon_bus_20261019/route_stops.csv', '대전시 노선정보 API getStaionByRouteAll, 같은 수집'),
          ('data/api/daejeon_bus_20261019/collect_log.json', '수집 기록(쪽별 건수, 시각, 인증키 없음)'),
          ('data/api/daejeon_bus_20261019/individual_query.csv', '미연결 ID 개별 조회 결과(getRouteInfo)'),
          ('data/api/daejeon_bus_20261019/tago_check.csv', '참고·비공식(TAGO 옮김 민간 사이트) 확인 기록'),
          ('data/api/daejeon_bus_20261019/buspos_check.csv', '버스 위치 조회 기록'),
          ('data/timetable_in/timetable_20260818.xlsx', '운송조합 시내버스 시간표(2026-08-18 게시 파일, 사용자 제공)'),
          ('data/ext/admdong.geojson', '행정동 경계 vuski ver20250701 중 대전광역시만 잘라 담음(코드는 동구·중구만 사용)'),
          ('data/colab_in/arrive_check2/arrive_check_20261019_0545/arrivals.csv', '도착정보 관측(보조), 2026-10-19 14:45~15:43 KST, 시각은 UTC 기록'),
          ('data/colab_in/arrive_check2/arrive_check_20261019_0545/summary.csv', '관측 요약'),
          ('data/colab_in/arrive_check2/arrive_check_20261019_0545/obs_log.json', '관측 기록'),
          ('out/dong_pop.csv', '2025 행정동 인구·고령 인구(사용자 제공 자료에서 정리)'),
          ('out/v3/buildings_points.gpkg', '주거 건물 대표점 39,077동(v3_step3_buildings.py가 건물 shp AL_D010에서 만든 중간 결과)')]
OUTS = ['out/v3/route_table.csv'] + [f'out/v5/{f}' for f in [
    'abc_map_v5.png', 'abc_results_v5.csv', 'abc_info_v5.json', 'abc_stability_v5.csv', 'abc_decomposition_v5.csv', 'abc_missed_by_dong_v5.csv',
    'dong_summary_v5.csv', 'buildings_lowaccess_v5.csv', 'buildings_scored_v5tt.csv', 'buildings_scored_v5api.csv',
    'route_stop_headway_v5.csv', 'route_headway_v5.csv', 'tt_scan_blocks_v5.csv', 'unlinked_id_judgement_v5.csv',
    'route_completion_table_v5.csv', 'stop_duplicate_candidates_v5.csv', 'analysis_parameters_v5tt.json', 'analysis_parameters_v5api.json']]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
man = []
for f in CODE:
    (STG / 'code').mkdir(parents=True, exist_ok=True); shutil.copy2(ROOT / 'code' / f, STG / 'code' / f)
for rel, desc in INPUTS:
    dst = STG / rel; dst.parent.mkdir(parents=True, exist_ok=True)
    if rel == 'data/ext/admdong.geojson':
        a = gpd.read_file(ROOT / rel); a[a.adm_nm.str.startswith('대전광역시')].to_file(dst, driver='GeoJSON')
        desc += f' (원본 전국 파일 sha256 {sha(ROOT / rel)[:16]}…)'
    else:
        shutil.copy2(ROOT / rel, dst)
    man.append(dict(구분='입력', 경로=rel, 바이트=dst.stat().st_size, sha256=sha(dst), 설명=desc))
for rel in OUTS:
    dst = STG / rel; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(ROOT / rel, dst)
    man.append(dict(구분='결과(run_all.py로 다시 생성됨)', 경로=rel, 바이트=dst.stat().st_size, sha256=sha(dst), 설명=''))
pd.DataFrame(man).to_csv(STG / '입력·결과_목록_v5.csv', index=False, encoding='utf-8-sig')
(STG / '읽어보기_v5.txt').write_text("""대전 동구·중구 버스 접근성 탐구 — v5 결과 (2026-10-19)

[먼저 볼 것]
out/v5/abc_map_v5.png               A·B·C(+D 탐색 비교)가 고른 8개 동, 포착(주황)·놓침(파랑)·미확인(청록 빈 원) 건물
out/v5/abc_results_v5.csv           방법별 포착률·집중도·놓침·선정 동 (주 분석 + 배차·집합·경계 민감도)
out/v5/abc_stability_v5.csv         경우를 바꿨을 때 8개 동 목록이 얼마나 같은지
out/v5/abc_decomposition_v5.csv     동별 저접근 비율 변화를 '분모 효과'와 '경계 효과'로 나눈 표
out/v5/dong_summary_v5.csv          동별 표(인구·고령·면적·정류장·A·B·C·미확인 제외·잠정·선정 여부)
out/v5/unlinked_id_judgement_v5.csv 미연결 9개 ID: 대체 후보 5 / 미확인 4, 근거와 '확인'으로 바꾸는 조건
out/v5/route_completion_table_v5.csv 완료표

[배차]
out/v5/route_headway_v5.csv         노선(갈래는 구간)별: 기점/회차지 정규·중간 출발 회차 수, 기본 배차, 근사 범위, (가) 값
out/v5/route_stop_headway_v5.csv    노선·정류장별 배차(h_tt 기본, h_api (가), h_best·h_worst 근사 범위)
out/v5/tt_scan_blocks_v5.csv        시간표 블록 검사(범례 색, 중간 출발 칸, 기점·회차지 회차 수)

[다시 실행]
1) 이 폴더(v5_결과)를 통째로 둔다. 경로는 모두 이 폴더 기준 상대 경로다.
2) python -I code/run_all.py   (약 3~4분)
   필요한 패키지: pandas, numpy, geopandas(pyogrio), shapely, scipy, openpyxl, matplotlib
   지도 글꼴: Noto Sans CJK (없으면 한글이 네모로 보일 수 있음 — 숫자 결과에는 영향 없음)
3) 원본 건물 shp(AL_D010)로 건물 대표점부터 다시 만들려면 data/bld/에 넣고 code/v3_step3_buildings.py를 먼저 실행
입력 파일 목록·크기·SHA-256: 입력·결과_목록_v5.csv
API 인증키는 어떤 파일에도 들어 있지 않다.
""", encoding='utf-8')
zp = ROOT / 'out/v5_결과_20261019.zip'
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(STG.rglob('*')):
        if p.is_file(): z.write(p, p.relative_to(STG.parent))
print(zp, round(zp.stat().st_size / 1e6, 1), 'MB,', len(man), '개 파일 목록')
