# A·B·C 비교 v5
# [사전 등록 규칙 — 그대로 유지]
#  주 분석 = 완전 사례: 미확인(미연결 ID) 도보권 건물을 뺀 집합. 저접근 = 그 집합 0.8m/s 점수 하위 20% 경계 이하(같은 값 포함)
#  A = 동 안 고유 정류장 ID 수(사용 노선이 서는 정류장, 이름 같고 1m 안 중복 1쌍만 통합) ÷ 2025 총인구 × 1만, 낮은 동부터
#  A′(비교) = 같은 이름 정류장을 120m 연결 묶음으로 센 값 / B = 분석 건물 평균 점수, 낮은 동부터 / C = 저접근 비율, 높은 동부터
#  8개 동(6·11 비교), 동점은 행정동 코드 오름차순 / 잠정 = 미확인 제외 건물이 동 주거건물의 10% 이상
# [추가 분석 — 검토 의견(2026-10-19) 반영, 결과를 본 뒤 추가했음을 기록]
#  D = 저접근 건물 수 상위(같은 K에서 포착 수를 최대로 만드는 기준, 계획 밖 탐색 비교)
#  집합 민감도: 대체 후보 도보권도 미확인으로 뺀 경우 / 전체 건물(하한 점수)
#  경계·분모 분해: {완전 사례, 전체 건물} × {주 분석 경계 고정, 각 집합 하위 20%}
#  배차 민감도: (가) 출처만 바꾼 값, 근사 범위의 가장 짧은/긴 배차
import json
from pathlib import Path
import numpy as np, pandas as pd, geopandas as gpd
from scipy.spatial import cKDTree
ROOT = Path(__file__).resolve().parents[1]
R = ROOT / 'data/api/daejeon_bus_20261019'; O3 = ROOT / 'out/v3'; O = ROOT / 'out/v5'
rd = lambda t: pd.read_csv(O / f'buildings_scored_v5{t}.csv', dtype={'bld_id': str, '행정동코드': str}).set_index('bld_id')
SC = {t: rd(t) for t in ['tt', 'api', 'best', 'worst']}
TT = SC['tt']
for t in SC: assert (SC[t].index == TT.index).all()
st = TT.자료상태
SETS = {'완전 사례(주 분석)': st != '미확인(미연결 ID)',
        '대체 후보도 제외(민감도)': st == '완전',
        '전체 건물(하한 점수)': pd.Series(True, index=TT.index)}

# ---- 동 기본표
adm = gpd.read_file(ROOT / 'data/ext/admdong.geojson').to_crs(5186)
area = adm[adm.adm_nm.str.contains(r'대전광역시 (?:동구|중구)')][['adm_cd2', 'adm_nm', 'geometry']].copy()
area['구'] = area.adm_nm.str.split().str[1]; area['행정동'] = area.adm_nm.str.split().str[2]
area['면적km2'] = area.geometry.area / 1e6
AREA_TOT = area.면적km2.sum()
pop = pd.read_csv(ROOT / 'out/dong_pop.csv')
D = area.drop(columns='geometry').merge(pop[['구', '동', '총인구_2025', '고령_2025']].rename(columns={'동': '행정동'}), on=['구', '행정동'], how='left')
assert D.총인구_2025.notna().all() and len(D) == 33
D = D.rename(columns={'adm_cd2': '행정동코드'}).set_index('행정동코드').sort_index()
D['고령비율'] = D.고령_2025 / D.총인구_2025

# ---- A: 사용 노선이 서는 정류장 (정책기관의 전체 정류장 등록 수와 같은 값이 아님)
rs = pd.read_csv(R / 'route_stops.csv', dtype=str).apply(lambda s: s.str.strip())
TB = pd.read_csv(O3 / 'route_table.csv', dtype=str)
rs = rs[rs.ROUTE_CD.isin(set(TB[TB.사용 == 'True'].ROUTE_CD))]
loc = (rs.groupby(['BUS_STOP_ID', 'GPS_LONG', 'GPS_LATI', 'BUSSTOP_NM']).ROUTE_CD.nunique().rename('노선수').reset_index()
         .sort_values(['BUS_STOP_ID', '노선수', 'GPS_LONG', 'GPS_LATI'], ascending=[True, False, True, True]).drop_duplicates('BUS_STOP_ID'))
# 5m 안 정류장 쌍(중복 등록 후보): 위치가 둘인 ID는 두 위치 모두 넣고 찾는다
la = rs.drop_duplicates(['BUS_STOP_ID', 'GPS_LONG', 'GPS_LATI'])
ga = gpd.GeoDataFrame(la[['BUS_STOP_ID', 'BUSSTOP_NM']], geometry=gpd.points_from_xy(pd.to_numeric(la.GPS_LONG), pd.to_numeric(la.GPS_LATI)), crs=4326).to_crs(5186)
ga = gpd.sjoin(ga, area[['adm_cd2', '행정동', 'geometry']], predicate='within').reset_index(drop=True)
rset = rs.groupby('BUS_STOP_ID').ROUTE_CD.apply(set)
pairs = []
for i, j in cKDTree(np.c_[ga.geometry.x, ga.geometry.y]).query_pairs(5.0):
    a, b = ga.loc[i], ga.loc[j]
    if a.BUS_STOP_ID == b.BUS_STOP_ID: continue
    pairs.append(dict(ID1=a.BUS_STOP_ID, 이름1=a.BUSSTOP_NM, ID2=b.BUS_STOP_ID, 이름2=b.BUSSTOP_NM, 거리m=round(a.geometry.distance(b.geometry), 2),
                      동=a.행정동, 노선1=len(rset[a.BUS_STOP_ID]), 노선2=len(rset[b.BUS_STOP_ID]), 겹치는노선=len(rset[a.BUS_STOP_ID] & rset[b.BUS_STOP_ID]),
                      처리='통합(이름 같고 1m 안)' if a.BUSSTOP_NM == b.BUSSTOP_NM and a.geometry.distance(b.geometry) <= 1.0 else '따로 셈'))
PAIRS = pd.DataFrame(pairs).drop_duplicates(['ID1', 'ID2']).sort_values('거리m')
PAIRS.to_csv(O / 'stop_duplicate_candidates_v5.csv', index=False, encoding='utf-8-sig')
assert set(PAIRS[PAIRS.처리.str.startswith('통합')][['ID1', 'ID2']].apply(frozenset, axis=1)) == {frozenset({'21030', '9001746'})}
g = gpd.GeoDataFrame(loc, geometry=gpd.points_from_xy(pd.to_numeric(loc.GPS_LONG), pd.to_numeric(loc.GPS_LATI)), crs=4326).to_crs(5186)
g = gpd.sjoin(g, area[['adm_cd2', 'geometry']], predicate='within').rename(columns={'adm_cd2': '행정동코드'}).drop(columns='index_right')
g['정류장'] = g.BUS_STOP_ID.replace({'9001746': '21030'})      # 보문오거리: 이름 같고 좌표 0m
D['정류장ID수'] = g.groupby('행정동코드').BUS_STOP_ID.nunique().reindex(D.index).fillna(0).astype(int)
D['정류장수'] = g.groupby('행정동코드').정류장.nunique().reindex(D.index).fillna(0).astype(int)
D['A_만명당정류장'] = D.정류장수 / D.총인구_2025 * 1e4
xy = np.c_[g.geometry.x, g.geometry.y]; names = g.BUSSTOP_NM.values
parent = list(range(len(g)))
def find(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]; a = parent[a]
    return a
for i, j in cKDTree(xy).query_pairs(120):
    if names[i] == names[j]: parent[find(i)] = find(j)
g['묶음'] = [find(i) for i in range(len(g))]
D['정류장묶음수'] = g.groupby('행정동코드').묶음.nunique().reindex(D.index).fillna(0).astype(int)
D['A묶음_만명당'] = D.정류장묶음수 / D.총인구_2025 * 1e4
grp_span = g.groupby('묶음').행정동코드.nunique()
STOPINFO = dict(정류장ID=int(g.BUS_STOP_ID.nunique()), 통합후=int(g.정류장.nunique()), 고유묶음=int(g.묶음.nunique()),
                동경계걸친묶음=int((grp_span > 1).sum()), 동별묶음합=int(D.정류장묶음수.sum()))
D['주거건물'] = TT.groupby('행정동코드').size().reindex(D.index)
D['미확인제외'] = (st == '미확인(미연결 ID)').groupby(TT.행정동코드).sum().reindex(D.index)
D['대체후보도보권'] = (st == '대체 후보 도보권(현행 ID로 계산)').groupby(TT.행정동코드).sum().reindex(D.index)
D['제외비율'] = D.미확인제외 / D.주거건물
D['잠정'] = D.제외비율 >= 0.10
D['제외비율_민감도'] = (D.미확인제외 + D.대체후보도보권) / D.주거건물
D['잠정_민감도'] = D.제외비율_민감도 >= 0.10

def dong_stats(score, subset, q=None):
    s = score[subset]
    q = s.quantile(0.2) if q is None else q
    b = pd.DataFrame({'동': TT.행정동코드[subset], 'L': s <= q, 's': s})
    o = b.groupby('동').agg(분석건물=('L', 'size'), 저접근건물=('L', 'sum'), B_평균점수=('s', 'mean')).reindex(D.index)
    o['C_저접근비율'] = o.저접근건물 / o.분석건물
    return q, o, b.L

METHODS = [('A', 'A 정류장 공급량', 'A_만명당정류장', True), ('A′', 'A′ 정류장 묶음(비교)', 'A묶음_만명당', True),
           ('B', 'B 동 평균 점수', 'B_평균점수', True), ('C', 'C 저접근 비율', 'C_저접근비율', False),
           ('D', 'D 저접근 건물 수(탐색 비교)', '저접근건물', False)]
def select(X, col, k, asc):
    t = X.reset_index().sort_values([col, '행정동코드'], ascending=[asc, True])
    return list(t.행정동코드.head(k))
def evaluate(X, k, meta, prov='잠정'):
    tot = X.저접근건물.sum(); out, sels = [], {}
    for key, name, col, asc in METHODS:
        sel = select(X, col, k, asc); sels[key] = sel; x = X.loc[sel]
        out.append(dict(meta, 선정수=k, 방법=name, 포착률=x.저접근건물.sum() / tot, 집중도=x.저접근건물.sum() / x.분석건물.sum(),
                        포착=int(x.저접근건물.sum()), 미포착=int(tot - x.저접근건물.sum()), 전체저접근=int(tot),
                        선정동_주거건물=int(x.주거건물.sum()), 선정동_분석건물=int(x.분석건물.sum()), 선정동_면적km2=x.면적km2.sum(),
                        선정동_면적비율=x.면적km2.sum() / AREA_TOT, 잠정동_포함=int(x[prov].sum()),
                        선정동=', '.join(X.loc[c, '행정동'] + ('*' if X.loc[c, prov] else '') for c in sel)))
    return out, sels

res, SEL, STAT = [], {}, {}
# 1) 주 분석(완전 사례) — 배차 4가지
for t, lab in [('tt', '(나) 기본'), ('api', '(가) 출처만 노선표'), ('best', '근사 범위: 가장 짧은 배차'), ('worst', '근사 범위: 가장 긴 배차')]:
    q, s, low = dong_stats(SC[t]['점수_0.8'], SETS['완전 사례(주 분석)'])
    X = D.join(s); STAT[('완전 사례(주 분석)', t)] = (q, X, low)
    for k in ((8, 6, 11) if t == 'tt' else (8,)):
        o, sels = evaluate(X, k, dict(집합='완전 사례(주 분석)', 경계='각 집합 하위 20%', 배차=lab, 경계값=q)); res += o; SEL[('완전 사례(주 분석)', t, k)] = sels
# 2) 집합 민감도 (배차 (나))
q_main = STAT[('완전 사례(주 분석)', 'tt')][0]
for setname, prov in [('대체 후보도 제외(민감도)', '잠정_민감도'), ('전체 건물(하한 점수)', '잠정')]:
    for qlab, qv in [('각 집합 하위 20%', None), ('주 분석 경계 고정', q_main)]:
        q, s, low = dong_stats(TT['점수_0.8'], SETS[setname], qv)
        X = D.join(s); STAT[(setname, 'tt', qlab)] = (q, X, low)
        o, sels = evaluate(X, 8, dict(집합=setname, 경계=qlab, 배차='(나) 기본', 경계값=q), prov=prov); res += o; SEL[(setname, qlab, 8)] = sels
Rz = pd.DataFrame(res)
Rz.to_csv(O / 'abc_results_v5.csv', index=False, encoding='utf-8-sig')

# ---- 동별 표
q0, X0, low0 = STAT[('완전 사례(주 분석)', 'tt')]
DT = X0.copy()
for key, *_ in METHODS:
    DT[f'선정_{key}'] = DT.index.isin(SEL[('완전 사례(주 분석)', 'tt', 8)][key])
for setname, qlab, tag in [('대체 후보도 제외(민감도)', '각 집합 하위 20%', '후보제외'), ('전체 건물(하한 점수)', '각 집합 하위 20%', '전체_자기경계'),
                           ('전체 건물(하한 점수)', '주 분석 경계 고정', '전체_고정경계')]:
    X = STAT[(setname, 'tt', qlab)][1]
    DT[f'분석건물_{tag}'] = X.분석건물; DT[f'저접근_{tag}'] = X.저접근건물; DT[f'B_{tag}'] = X.B_평균점수; DT[f'C_{tag}'] = X.C_저접근비율
DT.to_csv(O / 'dong_summary_v5.csv', encoding='utf-8-sig')

# ---- 2×2 분해 (C 값): {완전 사례, 전체 건물} × {주 분석 경계 고정, 각 집합 하위 20%}
X_full_fix = STAT[('전체 건물(하한 점수)', 'tt', '주 분석 경계 고정')][1]; X_full_own = STAT[('전체 건물(하한 점수)', 'tt', '각 집합 하위 20%')][1]
dec = pd.DataFrame({'행정동': DT.행정동, '잠정': DT.잠정, '제외비율': DT.제외비율.round(3),
                    'C_완전사례_주경계': DT.C_저접근비율.round(4), 'C_전체건물_주경계고정': X_full_fix.C_저접근비율.round(4),
                    'C_전체건물_자기경계': X_full_own.C_저접근비율.round(4)})
dec['분모효과(경계 고정)'] = (dec.C_전체건물_주경계고정 - dec.C_완전사례_주경계).round(4)
dec['경계효과(집합 고정)'] = (dec.C_전체건물_자기경계 - dec.C_전체건물_주경계고정).round(4)
dec.to_csv(O / 'abc_decomposition_v5.csv', encoding='utf-8-sig')

# ---- 동 목록 안정성: 주 분석 (나) 8개 동과 각 경우 비교
base = SEL[('완전 사례(주 분석)', 'tt', 8)]
stab = []
for key2, sels in SEL.items():
    if key2[-1] != 8 or key2 == ('완전 사례(주 분석)', 'tt', 8): continue
    for key, *_ in METHODS:
        a, b = set(base[key]), set(sels[key])
        nmf = lambda s: ', '.join(D.loc[c, '행정동'] for c in sorted(s))
        stab.append(dict(경우=' / '.join(map(str, key2[:-1])), 방법=key, 같은동=len(a & b), 빠진동=nmf(a - b), 들어온동=nmf(b - a)))
STAB = pd.DataFrame(stab); STAB.to_csv(O / 'abc_stability_v5.csv', index=False, encoding='utf-8-sig')

# ---- 놓친 저접근 건물의 위치(주 분석 8개 동)
miss = pd.DataFrame({k: DT.저접근건물.where(~DT.index.isin(base[k]), 0) for k, *_ in METHODS})
miss.insert(0, '행정동', DT.행정동); miss.insert(1, '저접근건물', DT.저접근건물); miss.insert(2, 'C_저접근비율', DT.C_저접근비율.round(3)); miss.insert(3, '잠정', DT.잠정)
miss.sort_values('저접근건물', ascending=False).to_csv(O / 'abc_missed_by_dong_v5.csv', encoding='utf-8-sig')

# ---- 건물별 저접근(지도용) + 근사 범위로 판정이 흔들리는 건물
sub = SETS['완전 사례(주 분석)']
bl = TT[['행정동코드', '행정동', 'x', 'y', '점수_0.8', '자료상태']].copy()
bl['분석집합'] = sub; bl['저접근'] = False; bl.loc[sub, '저접근'] = low0
for k, *_ in METHODS:
    bl[f'포착_{k}'] = bl.저접근 & bl.행정동코드.isin(base[k])
s_hi, s_lo = SC['best']['점수_0.8'], SC['worst']['점수_0.8']
assert (s_hi >= TT['점수_0.8'] - 1e-9).all() and (TT['점수_0.8'] >= s_lo - 1e-9).all()
q_hi, q_lo = STAT[('완전 사례(주 분석)', 'best')][0], STAT[('완전 사례(주 분석)', 'worst')][0]
sure_low = sub & (s_hi <= q_lo); sure_not = sub & (s_lo > q_hi)
bl['근사범위_판정'] = np.where(~sub, '', np.where(sure_low, '확실히 저접근', np.where(sure_not, '확실히 아님', '범위에 따라 달라짐')))
bl.to_csv(O / 'buildings_lowaccess_v5.csv', encoding='utf-8-sig')

# ---- 하한 조건 점검 (전체 건물 분석이 허용되는지)
#  ① 점수식: 0.5×최댓값 + 0.5×합 → 노선이 하나 더해지거나 배차가 짧아지면 점수는 줄지 않는다 (무작위 시험으로 확인)
rng = np.random.default_rng(0)
for _ in range(2000):
    e = rng.random(rng.integers(1, 8)) * 3; f = lambda v: 0.5 * v.max() + 0.5 * v.sum()
    assert f(np.append(e, rng.random() * 3)) >= f(e) - 1e-12
    e2 = e.copy(); e2[rng.integers(len(e))] += rng.random(); assert f(e2) >= f(e) - 1e-12
#  ② 미확인·대체 후보 ID는 점수 계산에 들어가지 않음(현행 노선표 ID만 사용) → 그 노선이 실제로 다니면 점수는 지금보다 같거나 높다
used_ids = set(TB[TB.사용 == 'True'].ROUTE_CD)
assert not used_ids & {'30300136', '30300139', '30300109', '69690109', '30300097', '30300117', '30300142', '30300143', '30300116'}
#  ③ 그 경우 전체 건물 하위 20% 경계가 움직일 수 있는 범위와, 제외 건물 중 저접근이 될 수 있는 최대 수
sc = TT['점수_0.8']; ex = ~SETS['완전 사례(주 분석)']
q_full_lo = sc.quantile(0.2)
q_full_hi = np.quantile(np.concatenate([sc[~ex].values, np.full(ex.sum(), 1e9)]), 0.2)
LB = dict(전체경계_하한=float(q_full_lo), 전체경계_상한=float(q_full_hi), 제외건물=int(ex.sum()),
          제외건물중_저접근가능=int((sc[ex] <= q_full_hi).sum()), 완전사례중_경계사이=int(((sc > q_full_lo) & (sc <= q_full_hi) & ~ex).sum()),
          전체_저접근_하한점수=int((sc <= q_full_lo).sum()))
INFO = dict(정류장=STOPINFO, 하한점검=LB, 근사범위=dict(경계_가장짧은배차=float(q_hi), 경계_기본=float(q0), 경계_가장긴배차=float(q_lo),
            확실히저접근=int(sure_low.sum()), 확실히아님=int(sure_not.sum()), 달라질수있음=int((sub & ~sure_low & ~sure_not).sum()),
            고정경계에서_달라질수있음=int((sub & (s_lo <= q0) & (s_hi > q0)).sum())),
            면적합계km2=AREA_TOT, 잠정동=DT[DT.잠정].apply(lambda r: f"{r.행정동} {r.제외비율:.0%}", axis=1).tolist(),
            잠정동_민감도=DT[DT.잠정_민감도].apply(lambda r: f"{r.행정동} {r.제외비율_민감도:.0%}", axis=1).tolist())
json.dump(INFO, open(O / 'abc_info_v5.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1, default=str)

pd.set_option('display.width', 260); pd.set_option('display.max_colwidth', 110)
print(json.dumps(INFO, ensure_ascii=False, indent=0, default=str))
show = ['방법', '포착률', '집중도', '미포착', '선정동_주거건물', '선정동_분석건물', '선정동_면적비율', '잠정동_포함', '선정동']
for (a, b2, c2), grp in Rz.groupby(['집합', '경계', '배차'], sort=False):
    for k in sorted(grp.선정수.unique()):
        t = grp[grp.선정수 == k]
        print(f'\n== {a} | {b2} | {c2} | {k}개 동 (경계 {t.경계값.iloc[0]:.4f}, 저접근 {t.전체저접근.iloc[0]})')
        print(t[show].round(3).to_string(index=False))
print('\n== 동 목록 안정성 (주 분석 (나) 8개 동 대비)'); print(STAB.to_string(index=False))
print('\n== 놓친 저접근 건물이 많은 동'); print(miss.sort_values('저접근건물', ascending=False).head(12).to_string())
print('\n== 2×2 분해 (잠정 동과 문화2동)'); print(dec[dec.잠정 | (dec.행정동 == '문화2동')].to_string())
