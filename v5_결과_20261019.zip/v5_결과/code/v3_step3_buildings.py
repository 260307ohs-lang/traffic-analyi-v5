# 계획서 10장 3단계: 분석 지점 만들기 — 주거건물 ID·행정동·좌표·주택 유형 정리
# 무엇을: 건물 도형에서 주거건물(용도코드 01·02)을 고르고, 같은 건물 중복을 합친 뒤, 대표점이 들어가는 행정동을 붙인다.
# 왜:     건물 하나가 두 번 세어지거나, 주소와 경계가 달라 동이 잘못 붙으면 동별 비교가 틀어진다.
# 볼 것:  건수 대조표(전체 → 연구지역 → 주거 → 중복 합침)와 제외·미확인 건수.
import numpy as np, pandas as pd, geopandas as gpd, glob
from pathlib import Path as _P
S = str(_P(__file__).resolve().parents[1])   # 프로젝트 폴더(이 파일이 있는 code/의 상위)
O = S + '/out/v3'
f = glob.glob(S + '/data/bld/AL_D010_30_*.shp')[0]
cols = ['A1', 'A2', 'A8', 'A9', 'A12', 'A14', 'A22', 'A23', 'A26', 'A27']
b = gpd.read_file(f, encoding='cp949', columns=cols)
print('좌표계', b.crs.to_epsg(), '| 대전 전체 건물', len(b), '| 기준일(A22)', b.A22.value_counts().index[0])
b['A8'] = b.A8.astype('string')
b['code'] = b.A8.fillna('')

# 행정동 경계 (행정동 코드 adm_cd2, 2025-07-01 기준)
adm = gpd.read_file(S + '/data/ext/admdong.geojson').to_crs(5186)
area = adm[adm.adm_nm.str.contains(r'대전광역시 (?:동구|중구)')][['adm_cd2', 'adm_nm', 'geometry']].copy()
area['구'] = area.adm_nm.str.split().str[1]; area['행정동'] = area.adm_nm.str.split().str[2]
print('행정동', len(area), '개 (동구', (area.구 == '동구').sum(), '/ 중구', (area.구 == '중구').sum(), ')')

# 같은 건물 식별번호(A1) 중복: 속성이 같은지 확인 후 하나로 합침 (모양이 다르면 합집합)
res = b[b.code.str[:2].isin(['01', '02'])].copy()
grp = res.groupby('A1')
n_rows = grp.size()
dup_ids = n_rows[n_rows > 1].index
attr = ['A2', 'A8', 'A14', 'A26', 'A27', 'A12']
same_attr = res[res.A1.isin(dup_ids)].groupby('A1')[attr].nunique().le(1).all(axis=1)
print('주거 후보(대전 전체)', len(res), '| A1 중복 그룹', len(dup_ids), '| 그중 속성 모두 같음', int(same_attr.sum()))
single = res[~res.A1.isin(dup_ids)]
def merge(g):
    geoms = list(g.geometry)
    same = all(geoms[0].equals(x) for x in geoms[1:])
    out = g.iloc[[0]].copy()
    if not same:
        out['geometry'] = [g.geometry.union_all()]
    out['합친행수'] = len(g); out['모양달라합집합'] = not same
    return out
merged = pd.concat([merge(g) for _, g in res[res.A1.isin(dup_ids)].groupby('A1')])
single = single.assign(합친행수=1, 모양달라합집합=False)
res = gpd.GeoDataFrame(pd.concat([single, merged]), crs=b.crs)
print('중복 합친 뒤 주거 후보', len(res), '(합쳐 없앤 행', int(n_rows.sum() - len(n_rows)), ', 모양 달라 합집합', int(merged.모양달라합집합.sum()), '그룹)')

# 대표점 → 행정동 (주소가 아니라 경계로 판정)
res['geometry'] = res.geometry.representative_point()
pt = gpd.sjoin(res, area, predicate='within', how='left').drop(columns='index_right')
assert pt.A1.is_unique
# 소속 구는 법적 주소(시군구코드 A23)로 정하고, 행정동은 경계로 붙인다.
# (행정동 경계는 지적 경계보다 덜 정밀해 구 경계 근처 건물이 이웃 구 행정동으로 들어갈 수 있음)
addr_gu = {'30110': '동구', '30140': '중구', '30170': '서구', '30200': '유성구', '30230': '대덕구'}
pt['주소구'] = pt.A23.map(addr_gu)
other_in = pt[pt.adm_cd2.notna() & ~pt.A23.isin(['30110', '30140'])]     # 주소는 다른 구인데 경계 안 → 제외
out_addr = pt[pt.adm_cd2.isna() & pt.A23.isin(['30110', '30140'])]       # 주소는 동구·중구인데 경계 밖 → 확인 필요
inside = pt[pt.adm_cd2.notna() & pt.A23.isin(['30110', '30140'])].copy()
inside['주소구일치'] = inside.주소구 == inside.구
print('주소 동구·중구 + 33개 동 경계 안 주거건물', len(inside), '| 주소는 동구·중구인데 경계 밖', len(out_addr),
      '| 주소는 다른 구인데 경계 안(제외)', len(other_in), other_in.주소구.value_counts().to_dict(),
      '| 동구↔중구 서로 다른 경우', int((~inside.주소구일치).sum()), inside.loc[~inside.주소구일치, ['주소구', '구']].value_counts().to_dict())

# 용도 미상(코드 결측) 건물: 연구지역 안에 몇 동인지만 기록 (주거 여부를 알 수 없어 분석에서 제외)
allp = b[b.A23.isin(['30110', '30140'])]
n_area_all = len(allp); n_unknown = int((allp.code == '').sum())
print('주소 동구·중구 전체 건물(행)', n_area_all, '| 용도코드 결측', n_unknown)

# 주택 유형(추정)·연면적
inside['연면적'] = pd.to_numeric(inside.A14, errors='coerce')        # 결측은 결측으로 (1㎡로 채우지 않음)
inside['연면적_유효'] = inside.연면적 > 0
inside['지상층수'] = pd.to_numeric(inside.A26, errors='coerce')
inside['지하층수'] = pd.to_numeric(inside.A27, errors='coerce')
inside['건축면적'] = pd.to_numeric(inside.A12, errors='coerce')
def htype(r):
    if r.code.startswith('01'):
        return '단독주택(다가구 포함)'
    if np.isnan(r.지상층수):
        return '공동주택 층수 미상'
    return '공동주택 4층 이하' if r.지상층수 <= 4 else '공동주택 5층 이상'
inside['주택유형_추정'] = [htype(r) for r in inside.itertuples()]
inside['x'] = inside.geometry.x; inside['y'] = inside.geometry.y
keep = ['A1', 'A2', 'adm_cd2', '구', '행정동', '주소구', '주소구일치', 'A8', 'A9', '주택유형_추정', '지상층수', '지하층수',
        '연면적', '연면적_유효', '건축면적', 'A22', '합친행수', '모양달라합집합', 'x', 'y', 'geometry']
bp = inside[keep].rename(columns={'A1': 'bld_id', 'A2': 'pnu', 'adm_cd2': '행정동코드', 'A8': '용도코드', 'A9': '용도명', 'A22': '자료기준일'})
bp = bp.sort_values('bld_id').reset_index(drop=True)
bp.to_file(O + '/buildings_points.gpkg', driver='GPKG')
print('\n주택유형_추정', bp.주택유형_추정.value_counts().to_dict())
print('연면적: 결측', int(bp.연면적.isna().sum()), '/ 0 이하', int((bp.연면적 <= 0).sum()), '/ 유효', int(bp.연면적_유효.sum()),
      f'({bp.연면적_유효.mean() * 100:.1f}%)')
print('연면적 무효의 주택유형', bp[~bp.연면적_유효].주택유형_추정.value_counts().to_dict())
cnt = pd.DataFrame([
    ['대전 전체 건물(행)', len(b)], ['주소 동구·중구 건물(행)', n_area_all], ['그중 용도코드 결측(미상, 분석 제외)', n_unknown],
    ['대전 전체 주거 후보(행)', int(n_rows.sum())], ['같은 건물 중복 합침으로 줄어든 행(대전 전체)', int(n_rows.sum() - len(n_rows))],
    ['분석 지점: 주소 동구·중구 주거건물', len(bp)], ['  그중 동구 주소인데 중구 행정동 경계(또는 반대)', int((~bp.주소구일치).sum())],
    ['주소는 동구·중구인데 33개 동 경계 밖', len(out_addr)], ['주소는 다른 구인데 경계 안(제외)', len(other_in)],
    ['연면적 유효(>0)', int(bp.연면적_유효.sum())]], columns=['항목', '건수'])
cnt.to_csv(O + '/building_count_table.csv', index=False, encoding='utf-8-sig')
print(cnt.to_string(index=False))
