# 건물 점수 v5. 사용법: python -I code/v5_scores.py h_tt   (또는 h_api, h_best, h_worst, h_v4fix33)
#   노선 점수 = 30 ÷ (도보분 + 배차÷2 + 2),  도보분 = 직선거리×1.3 ÷ (속도×60), 도보 8분 넘으면 0
#   건물 점수 = 가장 높은 노선 점수 + 0.5 × 나머지 노선 점수 합  (= 0.5×최댓값 + 0.5×합: 어느 노선 점수가 올라도 줄지 않음)
#   한 노선의 정류장이 여러 곳 도보권이면 그 노선 점수가 가장 큰 정류장을 쓴다
# 자료상태: 미확인(미연결 ID) = 공식 확인 안 된 ID 4개의 정류장이 0.8m/s 도보 8분 안
#          대체 후보 도보권 = 대체 후보 ID 5개의 정류장이 도보 8분 안(현행 ID로만 계산, 옛 ID는 넣지 않음)
#          완전 = 그 밖
import sys, json
from pathlib import Path
import numpy as np, pandas as pd, geopandas as gpd
from scipy.spatial import cKDTree
COL = sys.argv[1] if len(sys.argv) > 1 else 'h_tt'
TAG = COL.replace('h_', '')
ROOT = Path(__file__).resolve().parents[1]
R = ROOT / 'data/api/daejeon_bus_20261019'; O3 = ROOT / 'out/v3'; O = ROOT / 'out/v5'
DET, WMAX, REL, RMAX = 1.3, 8.0, 2.0, round(1.0 * 60 * 10 / 1.3, 2)
UNCONFIRMED = ['30300136', '30300139', '30300109', '69690109']
CANDIDATE = ['30300097', '30300117', '30300142', '30300143', '30300116']
bp = gpd.read_file(O3 / 'buildings_points.gpkg')
XY = np.c_[bp.x.values, bp.y.values]
M = pd.read_csv(O / 'route_stop_headway_v5.csv', dtype={'BUS_STOP_ID': str, '모형노선': str})
M['h'] = M[COL]
assert M.h.notna().all() and (M.h > 0).all()
rs = pd.read_csv(R / 'route_stops.csv', dtype=str).apply(lambda s: s.str.strip())
g = gpd.GeoDataFrame(rs, geometry=gpd.points_from_xy(pd.to_numeric(rs.GPS_LONG), pd.to_numeric(rs.GPS_LATI)), crs=4326).to_crs(5186)
rs['x'] = g.geometry.x.values; rs['y'] = g.geometry.y.values
FAMS = {'F33': ['30300147', '30300148'], 'F61': ['30300027', '30300028'], 'F71': ['30300118', '30300119'],
        'F72': ['30300120', '30300098'], 'FM1': ['30300154', '30300156']}
pts = rs.drop_duplicates(['ROUTE_CD', 'BUS_STOP_ID', 'x', 'y'])[['ROUTE_CD', 'BUS_STOP_ID', 'x', 'y']]

def access(Mr, speeds=(0.8, 1.0)):
    out = []
    for route, q in Mr.groupby('모형노선', sort=False):
        q = q.drop_duplicates('BUS_STOP_ID')
        q = q.merge(pts[pts.ROUTE_CD.isin(FAMS.get(route, [route]))].drop_duplicates(['BUS_STOP_ID', 'x', 'y'])[['BUS_STOP_ID', 'x', 'y']],
                    on='BUS_STOP_ID').reset_index(drop=True)
        k = min(len(q), 12)
        d, i = cKDTree(q[['x', 'y']].values).query(XY, k=k, distance_upper_bound=RMAX)
        if k == 1: d, i = d[:, None], i[:, None]
        bi, kk = np.nonzero(np.isfinite(d))
        D = pd.DataFrame({'bi': bi, 'dist_m': d[bi, kk], 'si': i[bi, kk]})
        D['h'] = q.h.values[D.si]; D['BUS_STOP_ID'] = q.BUS_STOP_ID.values[D.si]; D['구간'] = q.구간.values[D.si]
        for v in speeds:
            w = D.dist_m * DET / (v * 60)
            D[f'e{v}'] = np.where(w <= WMAX, 30 / (w + D.h / 2 + REL), 0.0)
        for v in speeds:
            best = D.sort_values(['bi', f'e{v}', 'dist_m'], ascending=[True, False, True]).drop_duplicates('bi')
            best = best[best[f'e{v}'] > 0]
            out.append(pd.DataFrame({'bi': best.bi.values, '모형노선': route, '표시': q.표시.iloc[0], 'speed': v,
                                     'BUS_STOP_ID': best.BUS_STOP_ID.values, '구간': best.구간.values, 'dist_m': best.dist_m.values,
                                     'h': best.h.values, '노선점수': best[f'e{v}'].values}))
    L = pd.concat(out, ignore_index=True)
    L['도보분'] = L.dist_m * DET / (L.speed * 60); L['대기분'] = L.h / 2 + REL
    return L

def summarize(L, v):
    e = L[L.speed == v]
    agg = e.groupby('bi').노선점수.agg(['max', 'sum', 'size'])
    best = e.sort_values(['bi', '노선점수', '모형노선'], ascending=[True, False, True]).drop_duplicates('bi').set_index('bi')
    o = pd.DataFrame(index=range(len(XY)))
    o[f'점수_{v}'] = (agg['max'] + 0.5 * (agg['sum'] - agg['max'])).reindex(o.index).fillna(0.0)
    o[f'이용노선수_{v}'] = agg['size'].reindex(o.index).fillna(0).astype(int)
    o[f'점수0_{v}'] = o[f'이용노선수_{v}'] == 0
    for c, src in [('대표노선', '모형노선'), ('대표노선표시', '표시'), ('대표정류장', 'BUS_STOP_ID'), ('대표구간', '구간'),
                   ('대표직선거리m', 'dist_m'), ('대표도보분', '도보분'), ('대표대기분', '대기분')]:
        o[f'{c}_{v}'] = best[src].reindex(o.index)
    o[f'대표총접근분_{v}'] = o[f'대표도보분_{v}'] + o[f'대표대기분_{v}']
    return o

L = access(M)
sc = pd.concat([summarize(L, 0.8), summarize(L, 1.0)], axis=1)
sc['손실률'] = np.where(sc['점수_1.0'] > 0, 1 - sc['점수_0.8'] / sc['점수_1.0'], np.nan)
def near(ids):
    p = rs[rs.ROUTE_CD.isin(ids)][['x', 'y']].drop_duplicates().values
    d, _ = cKDTree(p).query(XY, distance_upper_bound=0.8 * 60 * WMAX / DET)
    return np.isfinite(d)
nu, nc = near(UNCONFIRMED), near(CANDIDATE)
sc['자료상태'] = np.where(nu, '미확인(미연결 ID)', np.where(nc, '대체 후보 도보권(현행 ID로 계산)', '완전'))
sc['대체후보도보권'] = nc            # 미확인과 겹쳐도 표시 (민감도 분석용)
B = pd.concat([bp.drop(columns='geometry').reset_index(drop=True), sc], axis=1)
B.to_csv(O / f'buildings_scored_v5{TAG}.csv', index=False, encoding='utf-8-sig')
if TAG == 'tt':
    gpd.GeoDataFrame(B, geometry=bp.geometry.values, crs=bp.crs).to_file(O / 'buildings_scored_v5tt.gpkg', driver='GPKG')
    L['bld_id'] = bp.bld_id.values[L.bi]
    L.drop(columns=['bi']).to_csv(O / 'building_route_access_v5tt.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
json.dump(dict(version=COL, detour=DET, walk_limit_min=WMAX, reliability_min=REL, unconfirmed_ids=UNCONFIRMED, candidate_ids=CANDIDATE,
               headway={'h_tt': '(나) 시간표 기점 출발(중간 출발 제외)의 첫차~막차 평균 간격, 갈래는 구간별 회차, 33번은 범례 색, 시간표 없는 노선은 노선표',
                        'h_api': '(가) 시간표와 1:1 연결된 단일 노선만 노선표 배차, 갈래 계열·시간표 없는 노선은 (나)와 같음',
                        'h_best': '근사 범위 중 가장 짧은 배차(기점/회차지 방향, 중간 출발 포함 여부)', 'h_worst': '근사 범위 중 가장 긴 배차',
                        'h_v4fix33': '검토자 대조용: v4 값에서 33번만 색으로 고침'}[COL]),
          open(O / f'analysis_parameters_v5{TAG}.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'[{COL}] 점수 0: 0.8m/s {int(B["점수0_0.8"].sum())}동 | 자료상태', B.자료상태.value_counts().to_dict(), '| 대체후보 도보권(전체)', int(nc.sum()))
